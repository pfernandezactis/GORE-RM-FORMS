
"use client"

import * as React from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
  type DragOverEvent,
  type DragCancelEvent,
  DragOverlay,
  useDraggable,
  useDroppable,
} from "@dnd-kit/core"
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { cn } from "@/lib/utils"
import Image from "next/image"

import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
} from "@/components/ui/card"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import {
  Share2,
  GripVertical,
  Trash2,
  PlusCircle,
  X,
  Eye,
  Check,
  Rocket,
  PauseCircle,
  Play,
  CloudUpload,
  Star,
  ImageUp,
  Type,
  Pilcrow,
  CircleDot,
  ListChecks,
  ChevronDownSquare,
  Scaling
} from "lucide-react"
import { type Question } from "@/lib/mock-data"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { PlaceHolderImages } from "@/lib/placeholder-images"


function renderQuestionInput(question: Question) {
  switch (question.type) {
    case "long-text":
      return (
        <Textarea
          id={question.id}
          placeholder="Respuesta de texto largo"
          readOnly
          className="bg-muted"
        />
      )
    case "multiple-choice":
      return (
        <div className="space-y-2">
          {question.options?.map((opt, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="h-4 w-4 rounded-full border border-muted-foreground" />
              <Label className="font-normal text-muted-foreground">{opt}</Label>
            </div>
          )) || <p className="text-sm text-muted-foreground">Añada opciones de respuesta</p>}
        </div>
      )
    case "checkboxes":
      return (
        <div className="space-y-2">
          {question.options?.map((opt, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="h-4 w-4 rounded-sm border border-muted-foreground" />
              <Label className="font-normal text-muted-foreground">{opt}</Label>
            </div>
          )) || <p className="text-sm text-muted-foreground">Añada opciones de respuesta</p>}
        </div>
      )
    case "select":
       return <Input id={question.id} placeholder="Respuesta de lista desplegable" readOnly  className="bg-muted"/>
    case "likert-scale":
      return (
        <div className="space-y-2">
          {question.options?.map((opt, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="h-4 w-4 rounded-full border border-muted-foreground" />
              <Label className="font-normal text-muted-foreground">{opt}</Label>
            </div>
          )) || <p className="text-sm text-muted-foreground">Añada opciones de respuesta</p>}
        </div>
      )
    case "rating":
      return (
        <div className="flex items-center gap-1">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star key={i} className="h-6 w-6 text-muted-foreground" />
          ))}
        </div>
      )
    default:
      return <Input id={question.id} placeholder="Respuesta" readOnly className="bg-muted"/>
  }
}

function QuestionCard({ question }: { question: Question }) {
  return (
    <Card className="bg-card shadow-lg">
      <CardContent className="pt-6">
        <div className="flex items-start gap-4">
          <div
            className="mt-2 cursor-grabbing touch-none"
          >
            <GripVertical className="h-6 w-6 text-muted-foreground" />
          </div>
          <div className="flex-1 space-y-2">
            <Label htmlFor={question.id}>
                {question.label}
                {question.required && <span className="text-destructive ml-1">*</span>}
            </Label>
            {renderQuestionInput(question)}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function SortableQuestionCard({
  question,
  isSelected,
  onClick,
  onUpdateQuestion,
  onDeleteQuestion,
  isOverTop,
  isOverBottom,
}: {
  question: Question
  isSelected: boolean
  onClick: () => void
  onUpdateQuestion: (id: string, props: Partial<Question>) => void
  onDeleteQuestion: (id: string) => void
  isOverTop: boolean
  isOverBottom: boolean
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: question.id })

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 10 : "auto",
    opacity: isDragging ? 0 : 1,
  }

  const handleLabelChange = React.useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdateQuestion(question.id, { label: e.target.value })
  }, [question.id, onUpdateQuestion]);

  const handleOptionChange = React.useCallback((optionIndex: number, newText: string) => {
    const newOptions = [...(question.options || [])]
    newOptions[optionIndex] = newText
    onUpdateQuestion(question.id, { options: newOptions })
  }, [question.id, question.options, onUpdateQuestion]);

  const addOption = React.useCallback(() => {
    const newOptions = [
      ...(question.options || []),
      `Opción ${(question.options?.length || 0) + 1}`,
    ]
    onUpdateQuestion(question.id, { options: newOptions })
  }, [question.id, question.options, onUpdateQuestion]);

  const removeOption = React.useCallback((optionIndex: number) => {
    const newOptions = (question.options || []).filter(
      (_, i) => i !== optionIndex
    )
    onUpdateQuestion(question.id, { options: newOptions })
  }, [question.id, question.options, onUpdateQuestion]);
  
  const stopPropagation = React.useCallback((e: React.MouseEvent | React.KeyboardEvent) => {
    e.stopPropagation();
  }, [])

  return (
    <div ref={setNodeRef} style={style} {...attributes} onClick={onClick} className="relative">
       {isOverTop && (
        <div className="absolute -top-3 left-6 right-6 h-1.5 bg-primary rounded-full z-10" />
      )}
      <Card
        className={cn(
          "bg-card shadow-soft transition-all",
          isSelected ? "ring-2 ring-primary" : "border-transparent hover:shadow-md"
        )}
      >
        <div className="flex items-start gap-4 p-6">
          <div
            {...listeners}
            className="mt-2 cursor-grab active:cursor-grabbing touch-none"
          >
            <GripVertical className="h-6 w-6 text-muted-foreground" />
          </div>
          <div className="flex-1 space-y-4">
            {isSelected ? (
              <Input
                value={question.label}
                onChange={handleLabelChange}
                onClick={stopPropagation}
                onKeyDown={stopPropagation}
                placeholder="Escribe tu pregunta"
                className="text-base h-auto p-1 -ml-1 border-0 shadow-none focus-visible:ring-0 focus-visible:bg-muted/50"
              />
            ) : (
              <Label htmlFor={question.id} className="text-base font-normal">
                {question.label}
                {question.required && <span className="text-destructive ml-1">*</span>}
              </Label>
            )}

            <div onClick={stopPropagation} onKeyDown={stopPropagation}>
            {isSelected ? (
              <>
                {["multiple-choice", "checkboxes", "select", "likert-scale"].includes(
                  question.type
                ) && (
                  <div className="space-y-2">
                    {(question.options || []).map((option, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-2 group"
                      >
                        {question.type === "multiple-choice" && (
                          <div className="h-4 w-4 rounded-full border border-muted-foreground" />
                        )}
                         {question.type === "likert-scale" && (
                          <div className="h-4 w-4 rounded-full border border-muted-foreground" />
                        )}
                        {question.type === "checkboxes" && (
                          <div className="h-4 w-4 rounded-sm border border-muted-foreground" />
                        )}
                         {question.type === "select" && (
                          <span className="text-muted-foreground text-sm w-6 text-center">{index+1}.</span>
                        )}
                        <Input
                          value={option}
                          onChange={(e) =>
                            handleOptionChange(index, e.target.value)
                          }
                          className="h-9 border-0 hover:bg-muted/50 focus-visible:ring-0 focus-visible:bg-muted/50"
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeOption(index)}
                          className="shrink-0 h-8 w-8 opacity-0 group-hover:opacity-100"
                        >
                          <X className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    ))}
                    <div className="flex items-center gap-2">
                       {(question.type === "multiple-choice" || question.type === "likert-scale") && (
                          <div className="h-4 w-4 rounded-full border border-transparent" />
                        )}
                        {question.type === "checkboxes" && (
                          <div className="h-4 w-4 rounded-sm border border-transparent" />
                        )}
                         {question.type === "select" && (
                          <span className="w-6"></span>
                        )}
                      <Button
                        variant="link"
                        size="sm"
                        onClick={addOption}
                        className="text-primary p-0 h-auto"
                      >
                        Añadir opción
                      </Button>
                    </div>
                  </div>
                )}

                {question.type === "short-text" && (
                  <Input
                    placeholder="Respuesta de texto corto"
                    readOnly
                    className="bg-transparent border-b-2 border-dashed border-0 rounded-none shadow-none p-0 focus-visible:ring-0 w-1/2"
                  />
                )}
                {question.type === "long-text" && (
                  <Textarea
                    placeholder="Respuesta de texto largo"
                    readOnly
                    className="bg-transparent border-b-2 border-dashed border-0 rounded-none shadow-none p-0 focus-visible:ring-0"
                  />
                )}
                 {question.type === 'rating' && (
                    <div className="flex items-center gap-1 py-2">
                        {Array.from({ length: 5 }).map((_, i) => (
                            <Star key={i} className="h-6 w-6 text-muted" />
                        ))}
                    </div>
                )}
              </>
            ) : (
              renderQuestionInput(question)
            )}
            </div>
          </div>
        </div>
        {isSelected && (
          <>
            <Separator />
            <div className="p-2 flex justify-between items-center">
                <div className="flex items-center gap-2 px-2" onClick={(e) => e.stopPropagation()}>
                    <Switch
                        id={`required-${question.id}`}
                        checked={!!question.required}
                        onCheckedChange={(checked) => onUpdateQuestion(question.id, { required: checked })}
                    />
                    <Label htmlFor={`required-${question.id}`}>Obligatorio</Label>
                </div>
                <Button variant="ghost" size="icon" onClick={() => onDeleteQuestion(question.id)}>
                    <Trash2 className="h-5 w-5 text-muted-foreground hover:text-destructive" />
                </Button>
            </div>
          </>
        )}
      </Card>
      {isOverBottom && (
        <div className="absolute -bottom-3 left-6 right-6 h-1.5 bg-primary rounded-full z-10" />
      )}
    </div>
  )
}

function DraggableFieldButton({ fieldType, icon: Icon, label }: { fieldType: string, icon: React.FC<any>, label: string }) {
  const { attributes, listeners, setNodeRef } = useDraggable({
      id: `field-control-${fieldType}`,
  });

  return (
      <Button
          suppressHydrationWarning
          ref={setNodeRef}
          variant="outline"
          className="justify-start"
          {...listeners}
          {...attributes}
      >
          <Icon className="mr-2 h-4 w-4" />
          {label}
      </Button>
  );
}

const AddQuestionPopoverContent = ({ onSelect, onOpenChange }: { onSelect: (type: Question['type']) => void, onOpenChange: (open: boolean) => void }) => {
    return (
        <PopoverContent className="w-60">
            <div className="grid gap-4">
                <p className="text-sm font-medium">Tipos de Campo</p>
                <div className="grid gap-2">
                {questionTypeControls.map(control => (
                    <Button 
                        key={control.type} 
                        variant="ghost" 
                        className="justify-start"
                        onClick={() => {
                            onSelect(control.type)
                            onOpenChange(false)
                        }}
                    >
                        <control.icon className="mr-2 h-4 w-4" />
                        {control.label}
                    </Button>
                ))}
                </div>
            </div>
        </PopoverContent>
    )
}

const EmptyFormCanvas = ({ onAddQuestion }: { onAddQuestion: (type: Question['type']) => void }) => {
  const { setNodeRef, isOver } = useDroppable({ id: 'form-canvas-droppable-empty' });
  const [popoverOpen, setPopoverOpen] = React.useState(false);

  return (
      <div ref={setNodeRef} className={cn("py-20 flex flex-col items-center justify-center text-center rounded-lg border-2 border-dashed space-y-4", isOver ? "border-primary bg-primary/10" : "border-border")}>
        <p className="text-lg font-semibold">Tu formulario está vacío</p>
        <p className="text-sm text-muted-foreground">
          Arrastra un control o añade una pregunta para empezar.
        </p>
        <Popover open={popoverOpen} onOpenChange={setPopoverOpen}>
            <PopoverTrigger asChild>
                <Button variant="default">
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Añadir Pregunta
                </Button>
            </PopoverTrigger>
            <AddQuestionPopoverContent onSelect={onAddQuestion} onOpenChange={setPopoverOpen} />
        </Popover>
      </div>
  );
}

const typeLabels: Record<string, string> = {
  'short-text': "Texto corto",
  'long-text': "Texto largo",
  'multiple-choice': "Opción Múltiple",
  'checkboxes': "Casillas de Verificación",
  'select': "Lista Desplegable",
  'likert-scale': 'Escala de Likert',
  'rating': 'Calificación'
};

const questionTypeControls: {type: Question['type'], label: string, icon: React.FC<any>}[] = [
    { type: 'short-text', label: 'Texto corto', icon: Type },
    { type: 'long-text', label: 'Texto largo', icon: Pilcrow },
    { type: 'multiple-choice', label: 'Opción Múltiple', icon: CircleDot },
    { type: 'checkboxes', label: 'Casillas', icon: ListChecks },
    { type: 'select', label: 'Desplegable', icon: ChevronDownSquare },
    { type: 'likert-scale', label: 'Escala Likert', icon: Scaling },
    { type: 'rating', label: 'Calificación', icon: Star },
]

export default function FormEditor() {
  const params = useParams<{ id: string }>();
  const { toast } = useToast();
  
  const [formTitle, setFormTitle] = React.useState("");
  const [formDescription, setFormDescription] = React.useState("");
  const [formImageUrl, setFormImageUrl] = React.useState<string | undefined>();
  const [questions, setQuestions] = React.useState<Question[]>([]);
  const [activeId, setActiveId] = React.useState<string | null>(null);
  const [overId, setOverId] = React.useState<string | null>(null);
  const [dropPosition, setDropPosition] = React.useState<'top' | 'bottom' | null>(null);
  const [selectedQuestionId, setSelectedQuestionId] = React.useState<string | null>(null);
  
  const [formStatus, setFormStatus] = React.useState<'draft' | 'published' | 'paused'>('draft');
  const [saveStatus, setSaveStatus] = React.useState<'saved' | 'saving'>('saved');
  const [isLoaded, setIsLoaded] = React.useState(false);

  const formUrl = typeof window !== 'undefined' ? `${window.location.origin}/f/${params.id}` : '';
  const saveTimeoutRef = React.useRef<NodeJS.Timeout>();

  const formHeaderImages = PlaceHolderImages.filter(p => p.id.startsWith('form-header-'));
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [addQuestionPopoverOpen, setAddQuestionPopoverOpen] = React.useState(false);


  React.useEffect(() => {
    const savedDataString = localStorage.getItem(`form-data-${params.id}`);
    if (savedDataString) {
        const savedData = JSON.parse(savedDataString);
        setFormTitle(savedData.title);
        setFormDescription(savedData.description);
        setQuestions(savedData.questions);
        setFormStatus(savedData.status);
    }
    const savedImageUrl = localStorage.getItem(`form-image-${params.id}`);
    if (savedImageUrl !== null) { // Check for null specifically
        setFormImageUrl(savedImageUrl || undefined);
    }
    setIsLoaded(true);
  }, [params.id]);


  // Debounced auto-save effect
  React.useEffect(() => {
    if (!isLoaded) {
      return;
    }

    setSaveStatus('saving');
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }

    saveTimeoutRef.current = setTimeout(() => {
      const existingDataString = localStorage.getItem(`form-data-${params.id}`);
      const existingData = existingDataString ? JSON.parse(existingDataString) : {};

      const formDataToSave = {
        ...existingData,
        id: params.id,
        title: formTitle,
        description: formDescription,
        questions: questions,
        status: formStatus,
      };

      localStorage.setItem(`form-data-${params.id}`, JSON.stringify(formDataToSave));
      localStorage.setItem(`form-image-${params.id}`, formImageUrl || '');
      
      setSaveStatus('saved');
    }, 500);

    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
    };
  }, [isLoaded, params.id, formTitle, formDescription, formImageUrl, questions, formStatus]);


  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  )

  const handleImageUpload = React.useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
        toast({
          variant: "destructive",
          title: "Imagen demasiado grande",
          description: "Por favor, selecciona una imagen de menos de 2MB.",
        });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  }, [toast]);

  const handlePublish = React.useCallback(() => {
    if (!formTitle.trim()) {
        toast({
            variant: "destructive",
            title: "Título requerido",
            description: "Por favor, asigna un título a tu formulario antes de publicarlo.",
        });
        return;
    }
    setFormStatus('published');
    toast({
        title: "¡Formulario publicado!",
        description: "Tu formulario ahora está activo y aceptando respuestas.",
    });
  }, [formTitle, toast]);

  const handleResume = React.useCallback(() => {
    setFormStatus('published');
    toast({
        title: "Formulario reanudado",
        description: "Tu formulario está activo nuevamente y aceptando respuestas.",
    });
  }, [toast]);

  const handleUpdate = React.useCallback(() => {
    toast({
        title: "Formulario actualizado",
        description: "Tus cambios han sido guardados y están visibles.",
    });
  }, [toast]);

  const handleShareClick = React.useCallback(() => {
    if (formStatus === 'published') {
      navigator.clipboard.writeText(formUrl);
      toast({
        title: "¡Enlace copiado!",
        description: "El enlace para compartir se ha copiado a tu portapapeles.",
      });
    }
  }, [formStatus, formUrl, toast]);

  const handleAddQuestion = React.useCallback((type: Question['type']) => {
    const newQuestion: Question = {
        id: `q_${Date.now()}`,
        type: type,
        label: `${typeLabels[type] || 'Campo'} sin título`,
        options: ['multiple-choice', 'checkboxes', 'select'].includes(type) 
                    ? ['Opción 1'] 
                    : type === 'likert-scale' 
                        ? ['Muy en desacuerdo', 'En desacuerdo', 'Neutral', 'De acuerdo', 'Muy de acuerdo']
                        : undefined,
        required: false,
    };

    setQuestions((currentQuestions) => [...currentQuestions, newQuestion]);
    setSelectedQuestionId(newQuestion.id)
  }, []);

  const handleUpdateQuestion = React.useCallback((questionId: string, newProps: Partial<Question>) => {
    setQuestions(qs => qs.map(q => q.id === questionId ? { ...q, ...newProps } : q));
  }, []);

  const handleDeleteQuestion = React.useCallback((questionId: string) => {
      setQuestions(qs => qs.filter(q => q.id !== questionId));
      if (selectedQuestionId === questionId) {
        setSelectedQuestionId(null);
      }
  }, [selectedQuestionId]);

  const handleDragStart = React.useCallback((event: DragStartEvent) => {
    setActiveId(event.active.id.toString());
  }, []);

  const handleDragOver = React.useCallback((event: DragOverEvent) => {
    const { over, active, activatorEvent } = event;
    const overIdStr = over ? String(over.id) : null;
    setOverId(overIdStr);

    if (!overIdStr || !active.id.toString().startsWith('field-control-') || overIdStr.startsWith('field-control-')) {
        setDropPosition(null);
        return;
    }
    
    if (overIdStr === 'form-canvas-droppable-empty') {
        setDropPosition('bottom');
        return;
    }
    
    if (over.rect) {
        const overMiddleY = over.rect.top + over.rect.height / 2;
        setDropPosition(activatorEvent.clientY < overMiddleY ? 'top' : 'bottom');
    }
  }, []);

  const handleDragCancel = React.useCallback(() => {
      setActiveId(null);
      setOverId(null);
      setDropPosition(null);
  }, []);
  
  const handleDragEnd = React.useCallback((event: DragEndEvent) => {
    const cleanup = () => {
        setActiveId(null);
        setOverId(null);
        setDropPosition(null);
    };

    const { active, over } = event;
    if (!over) {
        cleanup();
        return;
    }
    
    const activeIdStr = active.id.toString();
    const overIdStr = over.id.toString();

    const isAddingNewField = activeIdStr.startsWith('field-control-');
    if (isAddingNewField) {
        const fieldType = activeIdStr.replace('field-control-', '') as Question['type'];
        const newQuestion: Question = {
            id: `q_${Date.now()}`,
            type: fieldType,
            label: `${typeLabels[fieldType] || 'Campo'} sin título`,
            options: ['multiple-choice', 'checkboxes', 'select'].includes(fieldType) 
                        ? ['Opción 1'] 
                        : fieldType === 'likert-scale' 
                            ? ['Muy en desacuerdo', 'En desacuerdo', 'Neutral', 'De acuerdo', 'Muy de acuerdo']
                            : undefined,
            required: false,
        };

        let newQuestions;
        const overIndex = questions.findIndex((q) => q.id === overIdStr);

        if (overIdStr === 'form-canvas-droppable-empty') {
            newQuestions = [newQuestion];
        } else if (overIndex !== -1) {
            newQuestions = [...questions];
            const insertIndex = dropPosition === 'top' ? overIndex : overIndex + 1;
            newQuestions.splice(insertIndex, 0, newQuestion);
        } else {
            newQuestions = [...questions, newQuestion];
        }
        
        setQuestions(newQuestions);
        setSelectedQuestionId(newQuestion.id);
        cleanup();
        return;
    }
    
    const isSorting = questions.some(q => q.id === activeIdStr);
    if (isSorting && active.id !== over.id) {
         const oldIndex = questions.findIndex((item) => item.id === active.id);
         const newIndex = questions.findIndex((item) => item.id === over.id);

         if (oldIndex > -1 && newIndex > -1) {
             setQuestions((items) => arrayMove(items, oldIndex, newIndex));
         }
    }

    cleanup();
  }, [questions, dropPosition]);

  function renderOverlayContent() {
    if (!activeId) return null;

    const activeQuestion = questions.find((q) => q.id === activeId);
    if (activeQuestion) {
        return <QuestionCard question={activeQuestion} />;
    }

    const isFieldControl = activeId.startsWith('field-control-');
    if (isFieldControl) {
        const fieldType = activeId.replace('field-control-', '');
        const control = questionTypeControls.find(c => c.type === fieldType)
        if (!control) return null;

        return (
            <Button variant="outline" className="justify-start bg-card shadow-lg">
                <control.icon className="mr-2 h-4 w-4" />
                {control.label}
            </Button>
        );
    }

    return null;
  }

  return (
    <div className="flex flex-col h-full">
      <header className="flex items-center justify-between mb-6">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/dashboard">Panel de Control</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>{formTitle}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            {saveStatus === 'saving' && <span>Guardando...</span>}
            {saveStatus === 'saved' && <span className="flex items-center gap-1"><Check className="h-4 w-4" /> Todos los cambios guardados</span>}
          </div>
          
          <TooltipProvider delayDuration={0}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" asChild>
                  <Link href={`/f/${params.id}`} target="_blank">
                    <Eye className="h-4 w-4" />
                    <span className="sr-only">Vista previa</span>
                  </Link>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Vista previa</p>
              </TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" disabled={formStatus !== 'published'} onClick={handleShareClick}>
                  <Share2 className="h-4 w-4" />
                    <span className="sr-only">Compartir</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Compartir</p>
              </TooltipContent>
            </Tooltip>
            
            {formStatus === 'published' && (
              <Tooltip>
                <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" onClick={() => setFormStatus('paused')}>
                        <PauseCircle className="h-4 w-4" />
                        <span className="sr-only">Pausar</span>
                    </Button>
                </TooltipTrigger>
                <TooltipContent>
                    <p>Pausar</p>
                </TooltipContent>
              </Tooltip>
            )}
          </TooltipProvider>

          {formStatus === 'draft' && (
            <Button size="sm" onClick={handlePublish}>
              <Rocket className="mr-2 h-4 w-4" /> Publicar
            </Button>
          )}
          {formStatus === 'paused' && (
            <Button size="sm" onClick={handleResume}>
              <Play className="mr-2 h-4 w-4" /> Reanudar
            </Button>
          )}
          {formStatus === 'published' && (
            <Button size="sm" onClick={handleUpdate}>
              <CloudUpload className="mr-2 h-4 w-4" /> Actualizar
            </Button>
          )}
        </div>
      </header>
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        onDragOver={handleDragOver}
        onDragCancel={handleDragCancel}
      >
        <div className="grid md:grid-cols-[280px_1fr] gap-8 flex-1">
          <Card className="hidden md:block">
            <CardContent className="pt-6">
              <div className="text-sm font-semibold mb-4">Controles de Campos</div>
              <p className="text-xs text-muted-foreground mb-4">
                  Arrastra y suelta campos en tu formulario.
              </p>
              <Accordion type="single" collapsible defaultValue="item-1" className="w-full">
                 {
                    Object.entries({
                        'Texto': ['short-text', 'long-text'],
                        'Opciones': ['multiple-choice', 'checkboxes', 'select'],
                        'Escalas': ['likert-scale', 'rating'],
                    }).map(([groupName, types], index) => (
                         <AccordionItem key={groupName} value={`item-${index + 1}`}>
                            <AccordionTrigger>{groupName}</AccordionTrigger>
                            <AccordionContent className="grid gap-2">
                                {types.map(type => {
                                    const control = questionTypeControls.find(c => c.type === type);
                                    if (!control) return null;
                                    return (
                                        <DraggableFieldButton 
                                            key={type}
                                            fieldType={control.type} 
                                            icon={control.icon} 
                                            label={control.label} 
                                        />
                                    )
                                })}
                            </AccordionContent>
                        </AccordionItem>
                    ))
                 }
              </Accordion>
            </CardContent>
          </Card>

          <div 
            className="bg-muted/30 p-4 rounded-lg border -m-4 -mt-2"
            onClick={(e) => {
              if (e.target === e.currentTarget) {
                setSelectedQuestionId(null)
              }
            }}
          >
            <div className="max-w-3xl mx-auto space-y-6">
                <div className="bg-card rounded-lg shadow-sm overflow-hidden">
                    <div className="relative w-full aspect-[3/1] bg-muted group">
                        <Image
                            key={formImageUrl} 
                            src={formImageUrl || formHeaderImages[0].imageUrl} 
                            alt={formTitle} 
                            fill 
                            className="object-cover"
                        />
                        <div className="absolute inset-0 bg-black/30 flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <input
                                type="file"
                                ref={fileInputRef}
                                onChange={handleImageUpload}
                                accept="image/png, image/jpeg, image/gif"
                                className="hidden"
                            />
                            <Button variant="secondary" onClick={() => fileInputRef.current?.click()}>
                                <CloudUpload className="mr-2 h-4 w-4" />
                                Cambiar
                            </Button>
                             {formImageUrl && (
                                <Button variant="destructive" size="sm" onClick={() => setFormImageUrl(undefined)}>
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Quitar
                                </Button>
                            )}
                        </div>
                    </div>
                    <div className="p-6 space-y-4">
                        <Input
                          value={formTitle}
                          onChange={(e) => setFormTitle(e.target.value)}
                          placeholder="Título del Formulario"
                          className="text-4xl font-bold tracking-tight bg-transparent border-0 rounded-none shadow-none p-0 h-auto focus-visible:ring-0 -mx-1 px-1"
                        />
                        <Textarea
                          value={formDescription}
                          onChange={(e) => setFormDescription(e.target.value)}
                          placeholder="Descripción del formulario (opcional)"
                          className="bg-transparent border-0 rounded-none shadow-none p-0 h-auto focus-visible:ring-0 text-muted-foreground -mx-1 px-1 resize-none"
                          rows={1}
                        />
                    </div>
                    <Separator/>
                    <div className="p-6 space-y-6">
                        <SortableContext
                          items={questions.map((q) => q.id)}
                          strategy={verticalListSortingStrategy}
                        >
                          <div className="space-y-6">
                            {questions.length > 0 ? (
                              questions.map((q) => (
                                <SortableQuestionCard 
                                  key={q.id} 
                                  question={q} 
                                  isSelected={selectedQuestionId === q.id}
                                  onClick={() => setSelectedQuestionId(q.id)}
                                  onUpdateQuestion={handleUpdateQuestion}
                                  onDeleteQuestion={handleDeleteQuestion}
                                  isOverTop={overId === q.id && dropPosition === 'top' && !!activeId && activeId.startsWith('field-control-')}
                                  isOverBottom={overId === q.id && dropPosition === 'bottom' && !!activeId && activeId.startsWith('field-control-')}
                                />
                              ))
                            ) : (
                              <EmptyFormCanvas onAddQuestion={handleAddQuestion} />
                            )}
                          </div>
                        </SortableContext>

                        {questions.length > 0 && (
                            <div className="mt-6 flex justify-center">
                                <Popover open={addQuestionPopoverOpen} onOpenChange={setAddQuestionPopoverOpen}>
                                    <PopoverTrigger asChild>
                                        <Button variant="outline" size="sm">
                                            <PlusCircle className="mr-2 h-4 w-4" />
                                            Añadir Pregunta
                                        </Button>
                                    </PopoverTrigger>
                                    <AddQuestionPopoverContent onSelect={handleAddQuestion} onOpenChange={setAddQuestionPopoverOpen} />
                                </Popover>
                            </div>
                        )}
                    </div>
                </div>
            </div>
          </div>
        </div>
        <DragOverlay>
          {renderOverlayContent()}
        </DragOverlay>
      </DndContext>
    </div>
  )
}
