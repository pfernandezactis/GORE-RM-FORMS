import * as React from "react";
import Link from "next/link";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal, BarChart3, Share2, Trash2, Download, Pencil } from "lucide-react";
import type { Form } from "@/lib/mock-data";
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { useRouter, usePathname } from "next/navigation";
import { useToast } from "@/hooks/use-toast";

type FormCardProps = {
  form: Form;
  onDeleteRequest: (form: Form) => void;
  onDownloadRequest?: (form: Form) => void;
};

const FormCard = React.memo(({ form, onDeleteRequest, onDownloadRequest }: FormCardProps) => {
  const router = useRouter();
  const pathname = usePathname();
  const { toast } = useToast();

  const creationDate = format(parseISO(form.createdAt), "dd 'de' MMMM, yyyy", { locale: es });
  const isResultsPage = pathname === '/results';
  
  const formUrl = typeof window !== 'undefined' ? `${window.location.origin}/f/${form.id}` : '';

  const handleCardClick = React.useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    // Prevent navigation if a button, link, or dropdown item was clicked
    if ((e.target as HTMLElement).closest('a, button, [role="menuitem"], [role="dialog"]')) {
        return;
    }
    
    const targetUrl = isResultsPage ? `/forms/${form.id}/analysis?from=results` : `/forms/${form.id}/edit`;
    router.push(targetUrl);
  }, [isResultsPage, form.id, router]);

  const handleDelete = React.useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    onDeleteRequest(form);
  }, [form, onDeleteRequest]);

  const handleDownload = React.useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    if (onDownloadRequest) {
      onDownloadRequest(form);
    }
  }, [form, onDownloadRequest]);
  
  const handleShareClick = React.useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    if (form.status === 'published') {
      navigator.clipboard.writeText(formUrl);
      toast({
        title: "¡Enlace copiado!",
        description: "El enlace para compartir se ha copiado a tu portapapeles.",
      });
    } else {
      toast({
        title: "Formulario no publicado",
        description: "Solo los formularios publicados se pueden compartir.",
        variant: "destructive"
      });
    }
  }, [form.status, formUrl, toast]);


  return (
    <>
      <Card onClick={handleCardClick} className="flex flex-col bg-card/80 backdrop-blur-sm border-white/20 shadow-soft cursor-pointer hover:shadow-lg transition-shadow">
        <CardHeader className="flex flex-row items-start justify-between gap-4">
          <div className="flex-1">
            <CardTitle className="text-base font-semibold leading-snug">{form.title}</CardTitle>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {isResultsPage ? (
                <>
                  <DropdownMenuItem asChild>
                    <Link href={`/forms/${form.id}/edit`}><Pencil className="mr-2 h-4 w-4" /> Editar formulario</Link>
                  </DropdownMenuItem>
                  {onDownloadRequest && (
                    <DropdownMenuItem onClick={handleDownload} onSelect={(e) => e.preventDefault()}>
                      <Download className="mr-2 h-4 w-4" /> Descargar (CSV)
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={handleShareClick} onSelect={(e) => e.preventDefault()}>
                    <Share2 className="mr-2 h-4 w-4" /> Compartir formulario
                  </DropdownMenuItem>
                </>
              ) : (
                <>
                  <DropdownMenuItem asChild>
                    <Link href={`/forms/${form.id}/analysis?from=dashboard`}><BarChart3 className="mr-2 h-4 w-4" /> Resultados</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleShareClick} onSelect={(e) => e.preventDefault()}>
                    <Share2 className="mr-2 h-4 w-4" /> Compartir
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    className="text-destructive focus:text-destructive-foreground focus:bg-destructive"
                    onSelect={(e) => e.preventDefault()}
                    onClick={handleDelete}
                  >
                    <Trash2 className="mr-2 h-4 w-4" /> Eliminar
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </CardHeader>
        <CardContent className="flex-grow">
          <div className="text-sm text-muted-foreground space-y-2">
              <p>Respuestas: <span className="font-medium text-foreground">{form.responseCount}</span></p>
              <p>Creado: <span className="font-medium text-foreground">{creationDate}</span></p>
          </div>
        </CardContent>
        <CardFooter>
        {form.status === "published" && (
            <Badge variant="secondary" className="bg-green-100 text-green-800 border-green-200 dark:bg-green-900/50 dark:text-green-300 dark:border-green-800">Publicado</Badge>
          )}
          {form.status === "draft" && (
            <Badge variant="outline">Borrador</Badge>
          )}
          {form.status === "paused" && (
              <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/50 dark:text-yellow-300 dark:border-yellow-800">Pausado</Badge>
          )}
        </CardFooter>
      </Card>
    </>
  );
});

FormCard.displayName = 'FormCard';
export default FormCard;
