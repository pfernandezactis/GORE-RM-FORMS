"use client"

import {
  Bar,
  BarChart,
  CartesianGrid,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

import {
  ChartContainer,
  ChartTooltipContent,
} from "@/components/ui/chart"

interface ResponseChartProps {
  data: { [key: string]: number } | undefined;
}

export default function ResponseChart({ data }: ResponseChartProps) {
  if (!data) return null;

  const chartData = Object.entries(data).map(([name, value]) => ({ name, value }));

  const chartConfig = {
    value: {
      label: "Respuestas",
      color: "hsl(var(--primary))",
    },
  }

  return (
    <ChartContainer config={chartConfig} className="min-h-[200px] w-full max-w-md justify-start">
      <BarChart accessibilityLayer data={chartData} layout="vertical">
        <CartesianGrid vertical={false} />
        <YAxis
          dataKey="name"
          type="category"
          tickLine={false}
          axisLine={false}
          tickMargin={10}
          width={150}
        />
        <XAxis dataKey="value" type="number" hide />
        <Tooltip cursor={false} content={<ChartTooltipContent />} />
        <Bar dataKey="value" fill="var(--color-value)" radius={4} />
      </BarChart>
    </ChartContainer>
  )
}
