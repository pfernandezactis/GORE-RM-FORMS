"use client"

import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import {
  LayoutGrid,
  BarChart3,
  ChevronDown,
} from "lucide-react"

import {
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
} from "@/components/ui/sidebar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Logo from "@/components/logo"
import { PlaceHolderImages } from "@/lib/placeholder-images"

const userAvatar = PlaceHolderImages.find(p => p.id === 'user-avatar');

export default function AppSidebar() {
  const pathname = usePathname()

  const isActive = (path: string) => {
    return pathname === path
  }

  return (
    <>
      <SidebarHeader className="p-4 items-center">
        <Link href="/dashboard">
          <Logo variant="inverted" />
        </Link>
      </SidebarHeader>
      <SidebarContent className="p-2">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              asChild
              isActive={isActive("/dashboard")}
              tooltip={{ children: "Panel de Control" }}
            >
              <Link href="/dashboard">
                <LayoutGrid />
                <span>Panel de Control</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton
              asChild
              isActive={isActive("/results")}
              tooltip={{ children: "Resultados" }}
            >
              <Link href="/results">
                <BarChart3 />
                <span>Resultados</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button suppressHydrationWarning variant="ghost" className="h-14 w-full justify-start">
                <div className="flex justify-between items-center w-full">
                    <div className="flex items-center gap-2">
                        {userAvatar && (
                          <Avatar className="h-9 w-9">
                            <AvatarImage src={userAvatar.imageUrl} alt="Avatar de Marcelo Salinas" data-ai-hint={userAvatar.imageHint} />
                            <AvatarFallback>MS</AvatarFallback>
                          </Avatar>
                        )}
                        <div className="text-left">
                            <p className="text-sm font-medium">Marcelo Salinas</p>
                            <p className="text-xs text-muted-foreground">m.salinas@gore.cl</p>
                        </div>
                    </div>
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56 mb-2" align="end" forceMount>
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium leading-none">Marcelo Salinas</p>
                <p className="text-xs leading-none text-muted-foreground">
                  m.salinas@gore.cl
                </p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Mi Perfil</DropdownMenuItem>
            <DropdownMenuItem>Cerrar Sesión</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarFooter>
    </>
  )
}
