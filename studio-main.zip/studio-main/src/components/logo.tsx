import { cn } from "@/lib/utils";
import Image from "next/image";

const Logo = ({ 
  className, 
  variant = 'default',
  width = 180,
  height = 40
}: { 
  className?: string, 
  variant?: 'default' | 'inverted',
  width?: number,
  height?: number
}) => (
  <div className={cn("flex items-center", className)}>
    <Image
      src="https://distrito-co.cl/wp-content/uploads/2024/12/LOGO-GOBIERNO-SANTIAGO-FULL-BW2-HORIZONTAL.png"
      alt="Logo Gobierno de Santiago"
      width={width}
      height={height}
      priority
      className={cn(variant === 'inverted' && 'invert')}
    />
  </div>
);

export default Logo;
