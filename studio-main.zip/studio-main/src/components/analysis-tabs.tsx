"use client"

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import dynamic from "next/dynamic"
import { Skeleton } from "@/components/ui/skeleton"
import type { Question, mockResponses } from "@/lib/mock-data"
import { Alert, AlertDescription, AlertTitle } from "./ui/alert"
import { Terminal } from "lucide-react"

const ResponseChart = dynamic(() => import("@/components/response-chart"), {
  ssr: false,
  loading: () => <Skeleton className="h-[250px] w-full" />,
})

type Responses = (typeof mockResponses)[keyof typeof mockResponses]

export default function AnalysisTabs({
  questions,
  responses,
}: {
  questions: Question[]
  responses?: Responses
}) {
  const chartableQuestions = questions.filter(q => 
    (q.type === 'multiple-choice' || q.type === 'select' || q.type === 'rating' || q.type === 'likert-scale') && responses?.summary[q.id]
  );

  if (!responses || !responses.individual.length) {
    return (
      <Card className="bg-card/80 backdrop-blur-sm border-white/20 shadow-soft text-center py-12">
        <CardContent>
            <p className="text-lg font-medium">Aún no hay respuestas.</p>
            <p className="text-muted-foreground">Comparte el formulario para empezar a recibir respuestas.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Tabs defaultValue="summary">
      <TabsList>
        <TabsTrigger value="summary">Resumen</TabsTrigger>
        <TabsTrigger value="individual">Respuestas Individuales</TabsTrigger>
      </TabsList>
      <TabsContent value="summary" className="space-y-4">
        {chartableQuestions.length > 0 ? (
          chartableQuestions.map(question => (
             <Card key={question.id} className="bg-card/80 backdrop-blur-sm border-white/20 shadow-soft">
              <CardHeader>
                <CardTitle>{question?.label}</CardTitle>
              </CardHeader>
              <CardContent className="pl-2">
                <ResponseChart data={responses?.summary[question.id]} />
              </CardContent>
            </Card>
          ))
        ) : (
          <Alert>
            <Terminal className="h-4 w-4" />
            <AlertTitle>Sin datos para graficar</AlertTitle>
            <AlertDescription>
              Este formulario no contiene preguntas con opciones múltiples, de selección o calificación que se puedan resumir en un gráfico.
            </AlertDescription>
          </Alert>
        )}
      </TabsContent>
      <TabsContent value="individual">
        <Card className="bg-card/80 backdrop-blur-sm border-white/20 shadow-soft">
          <CardHeader>
            <CardTitle>Respuestas Individuales</CardTitle>
            <CardDescription>
              Explora cada una de las respuestas enviadas.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {questions.map(q => <TableHead key={q.id}>{q.label}</TableHead>)}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {responses?.individual.map((response) => (
                    <TableRow key={response.id}>
                      {questions.map(q => (
                        <TableCell key={q.id}>{Array.isArray(response.answers[q.id]) ? response.answers[q.id].join(', ') : response.answers[q.id]?.toString() || "-"}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  )
}
