"use client";

import * as React from "react"
import { useSearchParams, useParams } from "next/navigation"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { type Form, type Question, type IndividualResponse } from "@/lib/mock-data"
import AnalysisTabs from "@/components/analysis-tabs"
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { convertToCSV } from "@/lib/data-manager";

function generateSummary(questions: Question[], individualResponses: IndividualResponse[]): { [questionId: string]: { [option: string]: number } } {
    const summaryData: { [questionId: string]: { [option: string]: number } } = {};

    if (!questions || !individualResponses || individualResponses.length === 0) {
        return summaryData;
    }

    const chartableQuestions = questions.filter(q =>
        q.type === 'multiple-choice' ||
        q.type === 'select' ||
        q.type === 'rating' ||
        q.type === 'likert-scale'
    );

    for (const question of chartableQuestions) {
        summaryData[question.id] = {};

        if (question.options) {
             question.options.forEach(opt => summaryData[question.id][opt] = 0);
        } else if (question.type === 'rating') {
            for (let i = 1; i <= 5; i++) {
                summaryData[question.id][`${i} Estrella${i > 1 ? 's' : ''}`] = 0;
            }
        }

        for (const response of individualResponses) {
            const answer = response.answers[question.id];

            if (answer === undefined || answer === null || answer === '') continue;

            if (question.type === 'rating') {
                const key = `${answer} Estrella${answer > 1 ? 's' : ''}`;
                if (summaryData[question.id].hasOwnProperty(key)) {
                  summaryData[question.id][key]++;
                }
            } else if (Array.isArray(answer)) {
                 answer.forEach(ans => {
                    if (summaryData[question.id].hasOwnProperty(ans)) {
                       summaryData[question.id][ans]++;
                    }
                })
            } else {
                 if (summaryData[question.id].hasOwnProperty(String(answer))) {
                    summaryData[question.id][String(answer)]++;
                 }
            }
        }
    }
    return summaryData;
}


function AnalysisPageSkeleton() {
    return (
    <div className="space-y-6">
       <div className="flex items-start justify-between">
         <Skeleton className="h-6 w-1/2" />
         <Skeleton className="h-9 w-36" />
       </div>
        <div className="flex justify-start">
            <Skeleton className="h-28 w-full max-w-xs" />
        </div>
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-96 w-full" />
    </div>
    )
}


export default function AnalysisPage() {
  const params = useParams<{ id: string }>();
  const [form, setForm] = React.useState<(Form & { questions: Question[] }) | null>(null)
  const [responses, setResponses] = React.useState<{ summary: any; individual: any[] } | undefined>(undefined);
  const searchParams = useSearchParams();
  const { toast } = useToast();
  
  const from = searchParams.get('from');
  const breadcrumbLink = from === 'results' ? '/results' : '/dashboard';
  const breadcrumbText = from === 'results' ? 'Resultados' : 'Panel de Control';

  React.useEffect(() => {
    if (params.id) {
        const savedDataString = localStorage.getItem(`form-data-${params.id}`);
        if (savedDataString) {
            setForm(JSON.parse(savedDataString));
        }
    }
  }, [params.id]);

  React.useEffect(() => {
    if (form && form.questions) {
      const responsesString = localStorage.getItem(`form-responses-${form.id}`);
      const individualResponses = responsesString ? JSON.parse(responsesString) : [];
      const summary = generateSummary(form.questions, individualResponses);
      setResponses({
        summary,
        individual: individualResponses
      });
    }
  }, [form]);

  const handleDownload = React.useCallback(() => {
    if (!form || !responses || !responses.individual || responses.individual.length === 0) {
        toast({
            variant: "destructive",
            title: "Sin datos",
            description: "No hay resultados para descargar para este formulario.",
        });
        return;
    }

    const csvData = convertToCSV(form.questions, responses.individual);
    if (!csvData) {
         toast({
            variant: "destructive",
            title: "Error de exportación",
            description: "No se pudo generar el archivo CSV. Verifique que el formulario tenga preguntas.",
        });
        return;
    }

    const blob = new Blob([`\uFEFF${csvData}`], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `resultados-${form.title.replace(/\s+/g, '_').toLowerCase()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, [form, responses, toast]);

  if (!form || !responses) {
    return <AnalysisPageSkeleton />;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href={breadcrumbLink}>{breadcrumbText}</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>{form.title} - Análisis</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <Button onClick={handleDownload} disabled={!responses || !responses.individual.length}>
            <Download className="mr-2 h-4 w-4" />
            Descargar (CSV)
        </Button>
      </div>

      <div className="flex justify-start">
        <Card className="w-full max-w-xs bg-card/80 backdrop-blur-sm border-white/20 shadow-soft">
          <CardHeader className="items-start space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Respuestas
            </CardTitle>
          </CardHeader>
          <CardContent>
            {responses ? (
                <div className="text-2xl font-bold text-left">{form.responseCount}</div>
            ) : (
                <Skeleton className="h-8 w-1/4 mt-1 mr-auto" />
            )}
          </CardContent>
        </Card>
      </div>
      
      {responses ? (
        <AnalysisTabs questions={form.questions} responses={responses} />
      ) : (
         <div className="space-y-4">
            <Skeleton className="h-10 w-48" />
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                </CardHeader>
                <CardContent>
                    <Skeleton className="h-[250px] w-full" />
                </CardContent>
            </Card>
         </div>
      )}
    </div>
  )
}
