"use client"

import dynamic from "next/dynamic"
import { Skeleton } from "@/components/ui/skeleton"

// Skeleton loader that mimics the editor's layout
function EditorSkeleton() {
  return (
    <div className="flex flex-col h-full">
      {/* Header Skeleton */}
      <header className="flex items-center justify-between mb-6">
        <Skeleton className="h-6 w-1/3" />
        <div className="flex items-center gap-4">
          <Skeleton className="h-9 w-24" />
          <Skeleton className="h-9 w-24" />
        </div>
      </header>
      <div className="grid md:grid-cols-[280px_1fr] gap-8 flex-1">
        {/* Controls Skeleton */}
        <Skeleton className="h-full w-full rounded-lg" />
        {/* Canvas Skeleton */}
        <div className="space-y-4">
            <Skeleton className="h-40 w-full rounded-lg" />
            <Skeleton className="h-60 w-full rounded-lg" />
        </div>
      </div>
    </div>
  )
}


const FormEditor = dynamic(() => import("@/components/form-editor"), {
  ssr: false,
  loading: () => <EditorSkeleton />,
})

export default function FormEditorPage() {
  return <FormEditor />
}
