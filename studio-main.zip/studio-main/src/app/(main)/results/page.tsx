"use client"

import * as React from "react"
import PageHeader from "@/components/page-header"
import { type Form, type Question } from "@/lib/mock-data"
import FormCard from "@/components/form-card"
import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card"
import { initializeFormData, loadFormsFromStorage, convertToCSV } from "@/lib/data-manager"
import { useToast } from "@/hooks/use-toast"

function FormCardSkeleton() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-4">
        <Skeleton className="h-5 w-3/4" />
        <Skeleton className="h-8 w-8" />
      </CardHeader>
      <CardContent className="flex-grow space-y-2">
        <Skeleton className="h-4 w-1/2" />
        <Skeleton className="h-4 w-2/3" />
      </CardContent>
      <CardFooter>
        <Skeleton className="h-6 w-20 rounded-full" />
      </CardFooter>
    </Card>
  )
}

export default function ResultsPage() {
  const [forms, setForms] = React.useState<Form[]>([])
  const [isLoading, setIsLoading] = React.useState(true)
  const { toast } = useToast();

  React.useEffect(() => {
    initializeFormData()
    const allForms = loadFormsFromStorage()
    const filteredForms = allForms.filter(f => f.responseCount > 0);
    setForms(filteredForms)
    setIsLoading(false)
  }, [])

  const handleDownloadRequest = React.useCallback((form: Form) => {
    const formString = localStorage.getItem(`form-data-${form.id}`);
    if (!formString) {
        toast({
            variant: "destructive",
            title: "Error",
            description: "No se pudieron cargar los datos del formulario para la exportación.",
        });
        return;
    }
    
    const fullForm = JSON.parse(formString);
    const questions = fullForm.questions as Question[] || [];
    
    const responsesString = localStorage.getItem(`form-responses-${form.id}`);
    const individualResponses = responsesString ? JSON.parse(responsesString) : [];

    if (!individualResponses || individualResponses.length === 0) {
        toast({
            variant: "destructive",
            title: "Sin datos",
            description: "No hay resultados para descargar para este formulario.",
        });
        return;
    }

    const csvData = convertToCSV(questions, individualResponses);
    if (!csvData) {
         toast({
            variant: "destructive",
            title: "Error de exportación",
            description: "No se pudo generar el archivo CSV. Verifique que el formulario tenga preguntas.",
        });
        return;
    }

    const blob = new Blob([`\uFEFF${csvData}`], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `resultados-${form.title.replace(/\s+/g, '_').toLowerCase()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, [toast])
  
  const handleDeleteRequest = React.useCallback(() => {
    toast({
        title: "Acción no disponible",
        description: "La eliminación de formularios se realiza desde el 'Panel de Control'.",
    })
  }, [toast]);

  return (
    <>
      <PageHeader title="Resultados y Análisis" />

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {isLoading
          ? Array.from({ length: 4 }).map((_, index) => (
              <FormCardSkeleton key={index} />
            ))
          : forms.map((form) => (
              <FormCard
                key={form.id}
                form={form}
                onDeleteRequest={handleDeleteRequest}
                onDownloadRequest={handleDownloadRequest}
              />
            ))}
      </div>
    </>
  )
}
