"use client"

import * as React from "react"
import { Button } from "@/components/ui/button"
import { PlusCircle, Loader2 } from "lucide-react"
import PageHeader from "@/components/page-header"
import { type Form } from "@/lib/mock-data"
import FormCard from "@/components/form-card"
import { useRouter } from "next/navigation"
import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card"
import { initializeFormData, loadFormsFromStorage, deleteFormFromStorage } from "@/lib/data-manager"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useToast } from "@/hooks/use-toast"

function FormCardSkeleton() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-4">
        <Skeleton className="h-5 w-3/4" />
        <Skeleton className="h-8 w-8" />
      </CardHeader>
      <CardContent className="flex-grow space-y-2">
        <Skeleton className="h-4 w-1/2" />
        <Skeleton className="h-4 w-2/3" />
      </CardContent>
      <CardFooter>
        <Skeleton className="h-6 w-20 rounded-full" />
      </CardFooter>
    </Card>
  )
}

export default function DashboardPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [forms, setForms] = React.useState<Form[]>([])
  const [isLoading, setIsLoading] = React.useState(true)
  const [isCreating, setIsCreating] = React.useState(false)

  const [formToDelete, setFormToDelete] = React.useState<Form | null>(null)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = React.useState(false)

  React.useEffect(() => {
    initializeFormData()
    const allForms = loadFormsFromStorage()
    setForms(allForms)
    setIsLoading(false)
  }, [])

  const handleDeleteRequest = React.useCallback((form: Form) => {
    setFormToDelete(form)
    setIsDeleteDialogOpen(true)
  }, [])

  const handleConfirmDelete = React.useCallback(() => {
    if (!formToDelete) return

    deleteFormFromStorage(formToDelete.id);

    toast({
      title: "Formulario eliminado",
      description: `"${formToDelete.title}" se ha eliminado correctamente.`,
    })
    
    window.location.reload();
  }, [formToDelete, toast])

  const handleCancelDelete = React.useCallback(() => {
    window.location.reload();
  }, [])

  const handleCreateForm = React.useCallback(() => {
    setIsCreating(true)

    // Using a short timeout to allow the UI to update to the "creating" state first.
    setTimeout(() => {
      const newId = `form-${Date.now()}`
      const newForm = {
        id: newId,
        title: "Nuevo Formulario",
        description: "Descripción del formulario (opcional)",
        createdAt: new Date().toISOString(),
        responseCount: 0,
        status: "draft",
        questions: [],
      }

      localStorage.setItem(`form-data-${newId}`, JSON.stringify(newForm))

      const formIdsString = localStorage.getItem("form-ids")
      const formIds = formIdsString ? JSON.parse(formIdsString) : []
      formIds.push(newId)
      localStorage.setItem("form-ids", JSON.stringify(formIds))

      router.push(`/forms/${newId}/edit`)
    }, 50)
  }, [router])

  return (
    <>
      <PageHeader title="Mis Formularios">
        <Button onClick={handleCreateForm} disabled={isCreating}>
          {isCreating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creando...
            </>
          ) : (
            <>
              <PlusCircle className="mr-2 h-4 w-4" />
              Crear Formulario
            </>
          )}
        </Button>
      </PageHeader>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {isLoading
          ? Array.from({ length: 6 }).map((_, index) => (
              <FormCardSkeleton key={index} />
            ))
          : forms.map((form) => (
              <FormCard
                key={form.id}
                form={form}
                onDeleteRequest={handleDeleteRequest}
              />
            ))}
      </div>

      <AlertDialog open={isDeleteDialogOpen}>
        <AlertDialogContent className="bg-card/80 backdrop-blur-sm border-white/20 shadow-soft">
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar formulario?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción es definitiva y no se puede deshacer. Se eliminará el formulario <strong>"{formToDelete?.title}"</strong> y todos sus resultados.
              Si no estás seguro, puedes pausar el formulario en su lugar.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={handleCancelDelete}>
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDelete}>
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
