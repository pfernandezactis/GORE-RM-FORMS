"use client";

import Link from "next/link";
import Image from "next/image";
import { useParams } from "next/navigation";
import * as React from "react";
import { mockForms, mockFormDetails, type Form, type Question } from "@/lib/mock-data";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import Logo from "@/components/logo";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { AlertCircle, Star, CheckCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { FormThemeProvider, useFormTheme } from '@/context/form-theme-context';

const formHeaderImage = PlaceHolderImages.find(p => p.id === 'form-header-image');

function renderFormControl(
    question: Question, 
    value: any, 
    onChange: (value: any) => void
) {
  switch (question.type) {
    case "short-text":
      return <Input id={question.id} placeholder="Tu respuesta" value={value || ""} onChange={e => onChange(e.target.value)} />;
    case "long-text":
      return <Textarea id={question.id} placeholder="Tu respuesta" value={value || ""} onChange={e => onChange(e.target.value)} />;
    case "multiple-choice":
      return (
        <RadioGroup id={question.id} className="space-y-2" value={value} onValueChange={onChange}>
          {question.options?.map((opt) => (
            <div key={opt} className="flex items-center space-x-3">
              <RadioGroupItem value={opt} id={`${question.id}-${opt}`} />
              <Label htmlFor={`${question.id}-${opt}`} className="font-normal cursor-pointer">
                {opt}
              </Label>
            </div>
          ))}
        </RadioGroup>
      );
    case "checkboxes":
        const checkedValues = value || [];
        const handleCheckboxChange = (option: string, checked: boolean) => {
            if (checked) {
                onChange([...checkedValues, option]);
            } else {
                onChange(checkedValues.filter((v: string) => v !== option));
            }
        };
      return (
        <div id={question.id} className="space-y-2">
          {question.options?.map((opt) => (
            <div key={opt} className="flex items-center space-x-3">
              <Checkbox 
                id={`${question.id}-${opt}`} 
                checked={checkedValues.includes(opt)}
                onCheckedChange={(checked) => handleCheckboxChange(opt, !!checked)}
              />
              <Label htmlFor={`${question.id}-${opt}`} className="font-normal cursor-pointer">
                {opt}
              </Label>
            </div>
          ))}
        </div>
      );
    case "select":
      return (
        <Select value={value} onValueChange={onChange}>
          <SelectTrigger id={question.id}>
            <SelectValue placeholder="Selecciona una opción" />
          </SelectTrigger>
          <SelectContent>
            {question.options?.map((opt) => (
              <SelectItem key={opt} value={opt}>
                {opt}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      );
    case 'likert-scale':
      return (
        <RadioGroup id={question.id} value={value} onValueChange={onChange} className="space-y-1">
          {question.options?.map((opt) => (
            <div key={opt} className="flex items-center space-x-3">
              <RadioGroupItem value={opt} id={`${question.id}-${opt}`} />
              <Label htmlFor={`${question.id}-${opt}`} className="font-normal cursor-pointer">
                {opt}
              </Label>
            </div>
          ))}
        </RadioGroup>
      );
    case 'rating':
        const ratingValue = value || 0;
        return (
            <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                    <button
                        type="button"
                        key={star}
                        aria-label={`${star} de 5 estrellas`}
                        onClick={() => onChange(star)}
                        className="p-2 rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                        <Star
                            className={cn(
                                "h-8 w-8",
                                star <= ratingValue ? "text-accent fill-accent" : "text-muted-foreground"
                            )}
                            aria-hidden="true"
                        />
                    </button>
                ))}
            </div>
        );
    default:
      return null;
  }
}

function SuccessScreen({ formTitle }: { formTitle: string }) {
  const [countdown, setCountdown] = React.useState(30);
  const redirectUrl = "https://www.gobiernosantiago.cl/";

  React.useEffect(() => {
    // Play a confirmation sound on mount
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      if (audioContext) {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(880, audioContext.currentTime);
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + 0.3);
        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.3);
      }
    } catch (error) {
      console.warn("Could not play confirmation sound.", error);
    }
  }, []);

  React.useEffect(() => {
    if (countdown <= 0) {
      window.location.href = redirectUrl;
      return;
    }

    const timer = setInterval(() => {
      setCountdown(prevCountdown => prevCountdown - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [countdown]);

  return (
    <Card className="w-full max-w-2xl text-center overflow-hidden">
      <CardContent className="p-8 sm:p-12">
        <div className="mx-auto w-fit">
          <Logo />
        </div>
        <CheckCircle className="mx-auto mt-8 h-16 w-16 text-success" />
        <h1 className="mt-6 text-2xl font-bold">¡Gracias por participar!</h1>
        <p className="mt-2 text-muted-foreground">
          Tus respuestas para la encuesta <br />
          <span className="font-semibold text-foreground">{formTitle}</span>
          <br />
          han sido enviadas correctamente.
        </p>
        <div className="mt-8">
            <p className="text-sm text-muted-foreground">
              Serás redirigido en <span className="font-bold text-foreground">{countdown}</span> segundos...
            </p>
            <Button variant="link" asChild className="mt-2">
                <a href={redirectUrl}>o haz clic aquí para ir ahora</a>
            </Button>
        </div>
      </CardContent>
    </Card>
  )
}

function PublicFormPage() {
  const params = useParams<{ id: string }>();

  const [form, setForm] = React.useState<Form & { questions?: Question[] } | null | undefined>(undefined);
  const { toast } = useToast();
  const [answers, setAnswers] = React.useState<Record<string, any>>({});
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [isSubmitted, setIsSubmitted] = React.useState(false);
  const { theme, setTheme, loading, setLoading } = useFormTheme();

  React.useEffect(() => {
    if (form?.title) {
      document.title = `GORE RM Forms - ${form.title}`;
    } else if (form === null) {
      document.title = `GORE RM Forms - Formulario no encontrado`;
    }
    
    return () => {
        document.title = 'GORE RM Forms';
    }
  }, [form]);

  React.useEffect(() => {
    setLoading(true);
    let themeClass = 'bg-gradient-default-form';
    if (params.id) {
        const savedDataString = localStorage.getItem(`form-data-${params.id}`);
        let formData: (Form & { questions?: Question[] }) | null = null;
        if (savedDataString) {
            formData = JSON.parse(savedDataString);
            const savedImageUrl = localStorage.getItem(`form-image-${params.id}`);
            if (savedImageUrl !== null) {
              formData.imageUrl = savedImageUrl || undefined;
            }
        } else {
            const mockForm = mockForms.find((f) => f.id === params.id);
            if (mockForm) {
                const mockQuestions = mockFormDetails[params.id as keyof typeof mockFormDetails];
                formData = { ...mockForm, questions: mockQuestions ?? [] };
            }
        }
        setForm(formData);

        let effectiveImageUrl = formData?.imageUrl;
        if (formData && !formData.imageUrl) {
            const defaultHeader = PlaceHolderImages.find(p => p.id === 'form-header-image');
            effectiveImageUrl = defaultHeader?.imageUrl;
        }

        if (effectiveImageUrl) {
            const cityscapeImage = PlaceHolderImages.find(p => p.id === 'form-header-image');
            const concertImage = PlaceHolderImages.find(p => p.id === 'form-header-2');
            const workspaceImage = PlaceHolderImages.find(p => p.id === 'form-header-3');

            if (effectiveImageUrl === cityscapeImage?.imageUrl) {
                themeClass = 'bg-gradient-santiago-cityscape';
            } else if (effectiveImageUrl === concertImage?.imageUrl) {
                themeClass = 'bg-gradient-santiago-concert';
            } else if (effectiveImageUrl === workspaceImage?.imageUrl) {
                themeClass = 'bg-gradient-workspace';
            }
        }
        setTheme(themeClass);
    }
    setLoading(false);

    return () => {
        setTheme('bg-gradient-default-form');
    }
  }, [params.id, setTheme, setLoading]);

  const handleAnswerChange = (questionId: string, value: any) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (isSubmitting) return;

      for (const question of (form?.questions ?? [])) {
          if (question.required && (answers[question.id] === undefined || answers[question.id] === '' || (Array.isArray(answers[question.id]) && answers[question.id].length === 0))) {
              if (window.navigator && window.navigator.vibrate) {
                window.navigator.vibrate(200); // Vibrate for 200ms on error
              }
              toast({
                  variant: "destructive",
                  title: "Respuesta requerida",
                  description: `Por favor, responde la pregunta: "${question.label}"`,
              });
              return;
          }
      }
      
      setIsSubmitting(true);
      
      // Save response to localStorage
      const responseId = `resp-${params.id}-${Date.now()}`;
      const newResponse = {
        id: responseId,
        answers: answers
      };

      const responsesString = localStorage.getItem(`form-responses-${params.id}`);
      const existingResponses = responsesString ? JSON.parse(responsesString) : [];
      existingResponses.push(newResponse);
      localStorage.setItem(`form-responses-${params.id}`, JSON.stringify(existingResponses));

      // Update response count in form data
      const formDataString = localStorage.getItem(`form-data-${params.id}`);
      if (formDataString) {
          const formData = JSON.parse(formDataString);
          formData.responseCount = (formData.responseCount || 0) + 1;
          localStorage.setItem(`form-data-${params.id}`, JSON.stringify(formData));
      }

      // Simulate API call and show success screen
      setTimeout(() => {
          setIsSubmitting(false);
          setIsSubmitted(true);
      }, 1000);
  };
  
  if (form === undefined) {
    return null;
  }

  if (form === null || form.status === "draft") {
    return (
      <Card className="w-full max-w-2xl p-8 text-center">
        <CardHeader>
          <CardTitle className="text-2xl">Formulario no encontrado</CardTitle>
          <CardDescription>
            El formulario que buscas no existe o no está disponible.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button asChild>
            <Link href="/">Volver al inicio</Link>
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (isSubmitted) {
      return <SuccessScreen formTitle={form.title} />;
  }

  if (form.status === "paused") {
    return (
      <Card className="w-full max-w-2xl p-8 text-center">
        <CardHeader>
          <div className="w-fit mx-auto bg-accent/10 p-3 rounded-full">
            <AlertCircle className="h-8 w-8 text-accent" />
          </div>
          <CardTitle className="mt-4">Formulario en pausa</CardTitle>
          <CardDescription className="max-w-md mx-auto">
            El formulario &quot;{form.title}&quot; no está aceptando respuestas en este
            momento. Por favor, inténtalo más tarde.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-2xl overflow-hidden">
       {(form.imageUrl || formHeaderImage) && (
        <div className="relative w-full aspect-[3/1] bg-muted">
            <Image 
                src={form.imageUrl || formHeaderImage!.imageUrl} 
                alt={form.title} 
                fill 
                className="object-cover"
                data-ai-hint={formHeaderImage?.imageHint}
                priority
            />
        </div>
      )}
      <CardHeader>
        <CardTitle className="text-3xl">{form.title}</CardTitle>
        {form.description && (
          <CardDescription className="pt-2">{form.description}</CardDescription>
        )}
      </CardHeader>
      <CardContent>
        <form className="space-y-8 mt-6" onSubmit={handleSubmit}>
          {(form.questions ?? []).map((q) => (
            <div key={q.id} className="grid w-full items-center gap-3">
              <Label htmlFor={q.id} className="text-base">
                {q.label}
                {q.required && <span className="text-destructive ml-1">*</span>}
              </Label>
              {renderFormControl(q, answers[q.id], (value) => handleAnswerChange(q.id, value))}
            </div>
          ))}
          <Button type="submit" size="lg" className="w-full sm:w-auto" disabled={isSubmitting}>
             {isSubmitting ? "Enviando..." : "Enviar respuestas"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

export default function FormEditorPage() {
  return (
    <FormThemeProvider>
      <PublicFormPage />
    </FormThemeProvider>
  );
}
