// This file is intentionally blank. 
// The layout functionality has been moved into the page component 
// to support the dynamic theming and loading screen.
export default function PublicFormLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
