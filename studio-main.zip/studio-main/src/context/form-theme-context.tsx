"use client";

import React, { createContext, useState, useContext, useEffect } from 'react';
import Logo from "@/components/logo";
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Contrast } from 'lucide-react';
import { TooltipProvider } from '@/components/ui/tooltip';

type FormThemeContextType = {
  theme: string;
  setTheme: (theme: string) => void;
  loading: boolean;
  setLoading: (loading: boolean) => void;
};

const FormThemeContext = createContext<FormThemeContextType | undefined>(undefined);

export const useFormTheme = () => {
  const context = useContext(FormThemeContext);
  if (!context) {
    throw new Error('useFormTheme must be used within a FormThemeProvider');
  }
  return context;
};

export const FormThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const [theme, setTheme] = useState('bg-gradient-default-form');
  const [loading, setLoading] = useState(true);
  const [isHighContrast, setIsHighContrast] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle('high-contrast', isHighContrast);
    return () => {
        document.documentElement.classList.remove('high-contrast');
    };
  }, [isHighContrast]);

  return (
    <FormThemeContext.Provider value={{ theme, setTheme, loading, setLoading }}>
      <TooltipProvider>
        <a 
          href="#main-content" 
          className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:p-3 bg-card text-card-foreground rounded-md shadow-lg z-50 font-semibold"
        >
          Saltar al contenido principal
        </a>
        {/* The children are always in the DOM tree, allowing their useEffect hooks to run. */}
        {/* The visibility of the layout is controlled by the `loading` state. */}
        <div style={{ visibility: loading ? 'hidden' : 'visible' }}>
          <div className={cn(
            "flex flex-col min-h-screen items-center transition-all duration-500", 
            isHighContrast ? 'bg-background' : theme
          )}>
            <main id="main-content" className="w-full flex-1 flex items-center justify-center p-4 sm:p-6 md:p-8">
              {children}
            </main>
            <footer className="py-8 w-full max-w-2xl mx-auto flex justify-center items-center text-sm text-muted-foreground px-4">
               <div className="flex items-center gap-4">
                <Logo width={140} height={32} variant={isHighContrast ? 'inverted' : 'default'} />
                {!loading && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="bg-card/80 backdrop-blur-sm"
                    onClick={() => setIsHighContrast(prev => !prev)}
                    aria-pressed={isHighContrast}
                  >
                    <Contrast className="h-4 w-4 mr-2" />
                    {isHighContrast ? 'Desactivar alto contraste' : 'Activar alto contraste'}
                  </Button>
                )}
              </div>
            </footer>
          </div>
        </div>

        {/* The loading indicator is shown on top when loading is true */}
        {loading && (
          <div className={cn(
            "fixed inset-0 z-50 flex items-center justify-center",
            isHighContrast ? "bg-background" : "bg-slate-100 dark:bg-slate-900"
            )}>
            <div className="animate-pulse">
              <Logo width={240} height={53} className="grayscale opacity-60" />
            </div>
          </div>
        )}
      </TooltipProvider>
    </FormThemeContext.Provider>
  );
};
