export type Form = {
  id: string;
  title: string;
  description?: string;
  imageUrl?: string;
  createdAt: string;
  responseCount: number;
  status: "published" | "draft" | "paused";
  questions?: Question[];
};

export const mockForms: Form[] = [
  {
    id: "form-1",
    title: "Encuesta de Satisfacción Ciudadana",
    description: "Ayúdanos a mejorar nuestros servicios respondiendo esta breve encuesta.",
    createdAt: "2024-05-10T10:00:00Z",
    responseCount: 5,
    status: "published",
  },
  {
    id: "form-2",
    title: "Postulación a Fondos Concursables 2024",
    description: "Postula tu proyecto para obtener financiamiento.",
    createdAt: "2024-05-15T14:30:00Z",
    responseCount: 3,
    status: "published",
  },
  {
    id: "form-3",
    title: "Registro de Asistencia a Evento Aniversario",
    description: "Confirma tu asistencia a la celebración de nuestro aniversario.",
    createdAt: "2024-06-01T09:00:00Z",
    responseCount: 3,
    status: "published",
  },
  {
    id: "form-4",
    title: "Sondeo sobre Necesidades de Capacitación",
    description: "Queremos saber qué temas te interesan para futuras capacitaciones.",
    createdAt: "2024-06-20T11:00:00Z",
    responseCount: 0,
    status: "draft",
  },
  {
    id: "form-5",
    title: "Reporte de Incidencias en la Vía Pública",
    description: "Informa sobre problemas en calles, veredas o alumbrado público.",
    createdAt: "2024-06-25T16:45:00Z",
    responseCount: 2,
    status: "paused",
  },
  {
    id: "form-6",
    title: "Inscripción a Talleres Culturales Gratuitos",
    description: "Inscríbete a los talleres de arte, música y más.",
    createdAt: "2024-07-01T12:00:00Z",
    responseCount: 3,
    status: "published",
  },
];

export type Question = {
  id: string;
  type: "short-text" | "long-text" | "multiple-choice" | "checkboxes" | "select" | "likert-scale" | "rating";
  label: string;
  options?: string[];
  required?: boolean;
};

export const mockFormDetails: { [key: string]: Question[] } = {
  "form-1": [
    {
      id: "q1-1",
      type: "multiple-choice",
      label: "¿Cuál es su nivel de satisfacción con los servicios municipales?",
      options: ["Muy Satisfecho", "Satisfecho", "Neutral", "Insatisfecho", "Muy Insatisfecho"],
      required: true,
    },
    {
      id: "q1-2",
      type: "long-text",
      label: "¿Qué aspectos podríamos mejorar? (Opcional)",
    },
  ],
  "form-2": [
    { id: "q2-1", type: "short-text", label: "Nombre del Proyecto", required: true },
    { id: "q2-2", type: "select", label: "Área del Proyecto", options: ["Cultura", "Deporte", "Medio Ambiente", "Social"], required: true },
    { id: "q2-3", type: "short-text", label: "Monto Solicitado (CLP)", required: true },
    { id: "q2-4", type: "long-text", label: "Breve Descripción del Proyecto", required: true },
  ],
  "form-3": [
      { id: "q3-1", type: "short-text", label: "Nombre Completo", required: true },
      { id: "q3-2", type: "multiple-choice", label: "¿Asistirá con acompañante?", options: ["Sí", "No"], required: true },
      { id: "q3-3", type: "multiple-choice", label: "¿Requiere estacionamiento?", options: ["Sí", "No"], required: true },
  ],
  "form-4": [
    { id: "q4-1", type: "checkboxes", label: "¿En qué áreas te gustaría recibir capacitación?", options: ["Tecnología", "Liderazgo", "Idiomas", "Marketing Digital", "Finanzas Personales"], required: true},
    { id: "q4-2", type: "short-text", label: "Si tienes otra sugerencia, indícala aquí." },
  ],
  "form-5": [
      { id: "q5-1", type: "select", label: "Tipo de Incidencia", options: ["Alumbrado Público", "Bache", "Acumulación de Basura", "Vereda Rota", "Señalética Dañada"], required: true },
      { id: "q5-2", type: "short-text", label: "Dirección (Calle y número)", required: true },
      { id: "q5-3", type: "long-text", label: "Describa brevemente la incidencia", required: false },
      { id: "q5-4", type: "rating", label: "Nivel de Urgencia", required: true },
  ],
  "form-6": [
      { id: "q6-1", type: "select", label: "Taller de Interés", options: ["Pintura al Óleo", "Guitarra Popular", "Teatro Comunitario", "Danza Moderna", "Fotografía Digital"], required: true},
      { id: "q6-2", type: "multiple-choice", label: "¿Posees experiencia previa en el área?", options: ["Sí", "No"], required: true },
      { id: "q6-3", type: "long-text", label: "¿Por qué te interesa participar en este taller?" },
  ],
};

export type IndividualResponse = {
    id: string;
    answers: { [questionId: string]: any };
}

type SummaryResponse = {
    [questionId: string]: { [option: string]: number };
}

type FormResponses = {
    summary: SummaryResponse;
    individual: IndividualResponse[];
}

export const mockResponses: { [formId: string]: FormResponses } = {
  "form-1": {
    summary: {
      "q1-1": { "Muy Satisfecho": 30, "Satisfecho": 50, "Neutral": 25, "Insatisfecho": 15, "Muy Insatisfecho": 5 },
    },
    individual: [
      { id: "resp-1-1", answers: { "q1-1": "Satisfecho", "q1-2": "Mejorar la iluminación en las plazas." } },
      { id: "resp-1-2", answers: { "q1-1": "Muy Satisfecho", "q1-2": "" } },
      { id: "resp-1-3", answers: { "q1-1": "Neutral", "q1-2": "Los tiempos de espera en oficinas son muy largos." } },
      { id: "resp-1-4", answers: { "q1-1": "Satisfecho", "q1-2": "Todo bien." } },
      { id: "resp-1-5", answers: { "q1-1": "Insatisfecho", "q1-2": "Falta de basureros en el centro." } },
    ]
  },
  "form-2": {
    summary: {
      "q2-2": { "Cultura": 25, "Deporte": 30, "Medio Ambiente": 15, "Social": 13 },
    },
    individual: [
        { id: "resp-2-1", answers: { "q2-1": "Reforestación Parque Metropolitano", "q2-2": "Medio Ambiente", "q2-3": "5.000.000", "q2-4": "Proyecto para plantar 1000 árboles nativos." } },
        { id: "resp-2-2", answers: { "q2-1": "Escuela de Fútbol para Niños", "q2-2": "Deporte", "q2-3": "2.500.000", "q2-4": "Fomentar el deporte en la comunidad." } },
        { id: "resp-2-3", answers: { "q2-1": "Festival de Teatro Vecinal", "q2-2": "Cultura", "q2-3": "8.000.000", "q2-4": "Montaje de 3 obras locales." } },
    ]
  },
  "form-3": {
    summary: {
      "q3-2": { "Sí": 12, "No": 22 },
      "q3-3": { "Sí": 9, "No": 25 },
    },
    individual: [
        { id: "resp-3-1", answers: { "q3-1": "Juan Pérez", "q3-2": "Sí", "q3-3": "No" } },
        { id: "resp-3-2", answers: { "q3-1": "María González", "q3-2": "No", "q3-3": "Sí" } },
        { id: "resp-3-3", answers: { "q3-1": "Pedro Castillo", "q3-2": "Sí", "q3-3": "Sí" } },
    ]
  },
  "form-5": {
    summary: {
      "q5-1": { "Alumbrado Público": 2, "Bache": 3, "Acumulación de Basura": 1, "Vereda Rota": 1 },
      "q5-4": { "1": 0, "2": 0, "3": 1, "4": 1, "5": 0 },
    },
    individual: [
        { id: "resp-5-1", answers: { "q5-1": "Bache", "q5-2": "Av. Principal 123", "q5-3": "Hay un hoyo grande en la calzada, peligroso para vehículos.", "q5-4": 4 } },
        { id: "resp-5-2", answers: { "q5-1": "Alumbrado Público", "q5-2": "Calle Secundaria 456", "q5-3": "El poste de luz de la esquina no enciende hace una semana.", "q5-4": 3 } },
    ]
  },
   "form-6": {
    summary: {
      "q6-1": { "Pintura al Óleo": 10, "Guitarra Popular": 15, "Teatro Comunitario": 12, "Danza Moderna": 8, "Fotografía Digital": 6 },
    },
    individual: [
        { id: "resp-6-1", answers: { "q6-1": "Guitarra Popular", "q6-2": "No", "q6-3": "Siempre quise aprender a tocar." } },
        { id: "resp-6-2", answers: { "q6-1": "Teatro Comunitario", "q6-2": "Sí", "q6-3": "Busco un espacio para seguir practicando." } },
        { id: "resp-6-3", answers: { "q6-1": "Fotografía Digital", "q6-2": "No", "q6-3": "Me gustaría aprender a sacar mejores fotos con mi cámara." } },
    ]
  },
};
