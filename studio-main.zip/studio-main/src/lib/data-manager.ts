import { mockForms, type Form, mockFormDetails, type Question, IndividualResponse, mockResponses } from "@/lib/mock-data";

const FORM_IDS_KEY = "form-ids";
const DATA_INITIALIZED_KEY = "gore-forms-data-initialized";

/**
 * Ensures mock data is seeded into localStorage on the user's first visit.
 * This improves performance by avoiding unnecessary synchronous writes on
 * every page load and prevents overwriting user-created forms.
 */
export function initializeFormData() {
  if (typeof window === 'undefined') return;

  // If we've already run this, we don't need to do it again.
  if (localStorage.getItem(DATA_INITIALIZED_KEY)) {
    return;
  }

  const mockFormIds = mockForms.map(form => form.id);
  
  mockForms.forEach((form) => {
    const storageKey = `form-data-${form.id}`;
    // We only seed data if a form with this ID doesn't already exist.
    // This prevents overwriting user data or edits.
    if (!localStorage.getItem(storageKey)) {
        const details = mockFormDetails[form.id as keyof typeof mockFormDetails] ?? [];
        
        const mockResp = mockResponses[form.id as keyof typeof mockResponses];
        
        // Seed responses if they exist in mock data
        if (mockResp && mockResp.individual && mockResp.individual.length > 0) {
          localStorage.setItem(`form-responses-${form.id}`, JSON.stringify(mockResp.individual));
        }
        
        const dataToStore = {
          ...form,
          // Sync response count with seeded mock responses.
          responseCount: (mockResp && mockResp.individual) ? mockResp.individual.length : 0,
          questions: details,
        };
        localStorage.setItem(storageKey, JSON.stringify(dataToStore));
    }
  });
  
  // Merge mock IDs with any potentially existing IDs to create a master list.
  const existingIdsString = localStorage.getItem(FORM_IDS_KEY);
  const existingIds = existingIdsString ? JSON.parse(existingIdsString) : [];
  const allIds = [...new Set([...mockFormIds, ...existingIds])];
  
  localStorage.setItem(FORM_IDS_KEY, JSON.stringify(allIds));
  
  // Set the flag so we don't run this expensive operation again.
  localStorage.setItem(DATA_INITIALIZED_KEY, "true");
}

/**
 * Loads all forms efficiently from localStorage using an index.
 * @returns An array of Form objects sorted by creation date.
 */
export function loadFormsFromStorage(): Form[] {
    if (typeof window === 'undefined') return [];
    
    const formIdsString = localStorage.getItem(FORM_IDS_KEY);
    if (!formIdsString) return [];

    const formIds: string[] = JSON.parse(formIdsString);
    const allForms: Form[] = [];

    for (const id of formIds) {
        const formString = localStorage.getItem(`form-data-${id}`);
        if (formString) {
            try {
                const savedData = JSON.parse(formString);
                // Basic validation to ensure it's a form object
                if (
                    savedData.id &&
                    savedData.title &&
                    savedData.createdAt &&
                    savedData.status
                ) {
                    // For list views, we don't need the full question data.
                    // Strip it out to improve performance and reduce memory usage.
                    const { questions, ...formMetaData } = savedData;
                    allForms.push(formMetaData);
                }
            } catch (e) {
                console.error(`Failed to parse form data for id ${id}`, e);
            }
        }
    }
    // Sort forms by creation date, newest first.
    return allForms.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

/**
 * Deletes a form and its related data from localStorage.
 * @param formId The ID of the form to delete.
 */
export function deleteFormFromStorage(formId: string) {
    if (typeof window === 'undefined') return;

    // 1. Remove form data from localStorage
    localStorage.removeItem(`form-data-${formId}`);
    localStorage.removeItem(`form-image-${formId}`);
    localStorage.removeItem(`form-responses-${formId}`);


    // 2. Update the form ID index
    const formIdsString = localStorage.getItem(FORM_IDS_KEY);
    if (formIdsString) {
      let formIds = JSON.parse(formIdsString) as string[];
      formIds = formIds.filter((id) => id !== formId);
      localStorage.setItem(FORM_IDS_KEY, JSON.stringify(formIds));
    }
}

/**
 * Converts form response data into a CSV formatted string.
 * @param questions The array of form questions to create headers.
 * @param responses The array of individual response objects.
 * @returns A string in CSV format.
 */
export function convertToCSV(questions: Question[], responses: IndividualResponse[]): string {
    if (!questions || questions.length === 0 || !responses || responses.length === 0) {
        return "";
    }

    const escapeCell = (cellValue: any): string => {
        let cell = String(cellValue ?? '');

        // If the cell contains a quote, a comma, or a newline, it needs to be quoted.
        const needsQuotes = cell.includes(',') || cell.includes('"') || cell.includes('\n') || cell.includes('\r');

        if (needsQuotes) {
            // Escape existing quotes by doubling them
            const escapedQuotes = cell.replace(/"/g, '""');
            // Wrap the entire cell in quotes
            return `"${escapedQuotes}"`;
        }

        return cell;
    };

    // Create header row
    const headerRow = questions.map(q => escapeCell(q.label)).join(',');

    // Create data rows
    const dataRows = responses.map(response => {
        return questions.map(q => {
            const answer = response.answers[q.id];
            if (Array.isArray(answer)) {
                return escapeCell(answer.join('; '));
            }
            return escapeCell(answer);
        }).join(',');
    });

    return [headerRow, ...dataRows].join('\n');
}
