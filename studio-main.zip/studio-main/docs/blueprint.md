# **App Name**: GORE Forms

## Core Features:

- Autenticación de Usuarios: Permitir a los funcionarios loguearse de forma segura usando correo electrónico y contraseña.
- Dashboard Personalizado: Mostrar una vista general de los formularios creados por el usuario, permitiendo una fácil gestión y acceso.
- Editor de Formularios en Tiempo Real: Implementar un editor intuitivo que permita crear y modificar formularios con vista previa instantánea.
- Análisis de Respuestas: Ofrecer herramientas para analizar las respuestas recibidas, incluyendo visualizaciones y resúmenes.
- Publicación y Gestión de URLs: Gestionar URLs únicas para cada formulario y controlar el estado de publicación.

## Style Guidelines:

- Fondo del sistema: #F2F2F7 (gris claro). Inspirado por la estética limpia y moderna de iOS, este color de fondo neutro asegura que el contenido principal resalte sin distracciones. Este color, sutilmente desaturado y cercano al blanco, promueve una sensación de amplitud y claridad, facilitando la lectura y navegación.
- Tarjetas y contenedores: #FFFFFF con 80% de opacidad (efecto Glassmorphism). Este blanco translúcido, combinado con una ligera opacidad, crea una experiencia visual atractiva y moderna. La superposición sobre el fondo #F2F2F7 genera un efecto de profundidad y sofisticación, reflejando el diseño minimalista de Apple.
- Acento principal: #2596be (azul institucional GORE RM). Este azul vibrante y saturado, conocido por su uso en el ecosistema de Apple, aporta un toque de modernidad y profesionalismo. Se utiliza para elementos interactivos y llamadas a la acción, garantizando que sean fácilmente identificables y accesibles. Este color transmite confianza, innovación y tecnología.
- Complementario: #e8490f Naranja GORE RM
- Font: 'San Francisco', un tipo de letra sans-serif diseñada por Apple, proporciona una legibilidad excelente y una estética moderna. Note: currently only Google Fonts are supported.
- Diseño de Single Page Application (SPA) centrado en el contenido para una experiencia de usuario fluida e ininterrumpida.
- Corner Radius: 12px para todos los elementos (botones, tarjetas, contenedores) para una apariencia moderna y suave.
- Sombras suaves: 0px 4px 20px rgba(0,0,0,0.05) para proporcionar una sutil elevación y distinción visual a los elementos.